package Atividade5_Sistemas_do_Dia_a_Dia3.Exercicio5_DeliveryRestaurante.Entities.Enums;

public enum StatusPagamento {
    APROVADO,
    RECUSADO
}
