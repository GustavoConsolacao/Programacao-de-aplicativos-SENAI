package Atividade5_Sistemas_do_Dia_a_Dia3.Exercicio6_ReservaHotel.Aplication;
import java_Sistemas_do_Dia_a_Dia_3.Entities.Hospede;
import java_Sistemas_do_Dia_a_Dia_3.Entities.Pagamento;
import java_Sistemas_do_Dia_a_Dia_3.Entities.Quarto;
import java_Sistemas_do_Dia_a_Dia_3.Entities.Reserva;

import java.util.Scanner;

        public class Main {

            public static void main(String[] args) {

                Scanner sc = new Scanner(System.in);

                System.out.println(" SISTEMA DE RESERVA DE HOTEL ");

                //Onde o Hospede vai colocar o nome
                System.out.print("Nome do hospede: ");
                String nome = sc.nextLine();

                //Cidade do Hospede
                System.out.print("Cidade: ");
                String cidade = sc.nextLine();

                //onde o sistema pede a quantidades dos hospedes
                System.out.print("Quantidade de hospedes: ");
                int quantidadeHospedes = sc.nextInt();

                //o numero de diarias
                System.out.print("Quantidade de diárias: ");
                int diarias = sc.nextInt();
                sc.nextLine();

                //Aqui Diz os quartos disponiveis e pergunta o tipo e o valor que vai ficar
                Quarto quarto = new Quarto(101, "Casal", 250.0);

                //Verifica disponibilidade
                if (!quarto.isDisponivel()) {
                    System.out.println("Nenhum quarto disponivel.");
                    sc.close();
                    return;
                }

                System.out.println("\nQuarto encontrado:");
                System.out.println(quarto);

                //Escolha da forma de pagamento
                System.out.print("\nForma de pagamento: ");
                String formaPagamento = sc.nextLine();

                //Criação dos objetos
                Hospede hospede = new Hospede(nome);

                Reserva reserva = new Reserva(hospede, quarto, diarias);

                Pagamento pagamento = new Pagamento(formaPagamento);

                //exibe valor da hospedagem
                System.out.println("\n Resumo da reserva ");
                System.out.println(reserva);

                //Validação do pagamento
                if (pagamento.validarPagamento()) {

                    quarto.reservar();

                    System.out.println("\n      Pagamento    ");
                    System.out.println(pagamento);

                    System.out.println("\nHospedagem registrada.");
                    System.out.println("Confirmação enviada por e-mail.");
                    System.out.println("Reserva confirmada.");

                } else {

                    System.out.println("Pagamento recusado.");

                }

                sc.close();
            }
        }

