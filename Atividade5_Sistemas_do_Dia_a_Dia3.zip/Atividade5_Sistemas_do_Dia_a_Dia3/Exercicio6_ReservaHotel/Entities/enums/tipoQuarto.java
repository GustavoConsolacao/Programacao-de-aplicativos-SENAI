package Atividade5_Sistemas_do_Dia_a_Dia3.Exercicio6_ReservaHotel.Entities.enums;

public enum tipoQuarto {
    SOLTEIRO,
    CASAL,
    LUXO
}
