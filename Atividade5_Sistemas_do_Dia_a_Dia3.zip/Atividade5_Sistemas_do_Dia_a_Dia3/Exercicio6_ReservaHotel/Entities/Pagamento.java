package Atividade5_Sistemas_do_Dia_a_Dia3.Exercicio6_ReservaHotel.Entities;

public class Pagamento {

    private String formaPagamento;
    private boolean aprovado;

    public Pagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
        this.aprovado = false;
    }

    public boolean validarPagamento() {
        // Simulação de aprovação
        aprovado = true;
        return aprovado;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public boolean isAprovado() {
        return aprovado;
    }

    public String toString() {
        return "Pagamento{" +
                "\nForma de Pagamento = " + formaPagamento +
                "\nStatus = " + (aprovado ? "Aprovado" : "Recusado") +
                "\n}";
    }
}

