package Atividade4_Interfaces.Aplication;

import Atividade4_Interfaces.Entities.*;
import Atividade4_Interfaces.Entities.Interfaces.ConectavelIoT;
import Atividade4_Interfaces.Entities.Interfaces.Manutenivel;
import Atividade4_Interfaces.Entities.Interfaces.Programavel;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Robo robo = new Robo("R001", "Robô Industrial");
        EsteiraTransportadora esteira = new EsteiraTransportadora("E001", "Esteira Principal");
        SensorTemperatura sensor = new SensorTemperatura("S001", "Sensor de Temperatura");
        CLP clp = new CLP("C001", "CLP Siemens");
        List<Equipamento> equipamentos = new ArrayList<>();
        equipamentos.add(robo);
        equipamentos.add(esteira);
        equipamentos.add(sensor);
        equipamentos.add(clp);
        System.out.println("STATUS DOS EQUIPAMENTOS: ");
        for (Equipamento equipamento : equipamentos) {
            System.out.println(equipamento.getNome());
            System.out.println(equipamento.status());
            System.out.println();
        }
        List<Manutenivel> manuteniveis = new ArrayList<>();
        manuteniveis.add(robo);
        manuteniveis.add(esteira);
        manuteniveis.add(clp);
        System.out.println("MANUTENÇÃO:");
        for (Manutenivel equipamento : manuteniveis) {
            equipamento.agendarManutencao();
            equipamento.diagnosticar();
            System.out.println();
        }
        List<ConectavelIoT> conectados = new ArrayList<>();
        conectados.add(robo);
        conectados.add(sensor);
        conectados.add(clp);
        System.out.println("CONEXÃO COM A NUVEM: ");
        for (ConectavelIoT equipamento : conectados) {
            equipamento.enviarDadosNuvem();
            System.out.println();
        }
        List<Programavel> programaveis = new ArrayList<>();
        programaveis.add(robo);
        programaveis.add(clp);
        System.out.println("PROGRAMAÇÃO: ");

        for (Programavel equipamento : programaveis) {
            equipamento.carregarPrograma("Programa de Produção");
        }
    }
}
