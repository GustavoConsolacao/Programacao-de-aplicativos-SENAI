package Atividade4_Interfaces.Entities;

import Atividade4_Interfaces.Entities.Interfaces.ConectavelIoT;
import Atividade4_Interfaces.Entities.Interfaces.Manutenivel;
import Atividade4_Interfaces.Entities.Interfaces.Programavel;

public class Robo extends MaquinaProducao implements Manutenivel, ConectavelIoT, Programavel {
    public Robo() {
        super();
    }
    public Robo(String codigo, String nome) {
        super(codigo, nome);
    }
    @Override
    public void enviarDadosNuvem() {
        System.out.println("Dados do robo enviados para a nuvem.");
    }

    @Override
    public void receberComando(String comando) {
        System.out.println("Comando recebido: "+comando);
    }

    @Override
    public void agendarManutencao() {
        System.out.println("Manutenção do robo agendada.");
    }

    @Override
    public void registrarFalha(String descricao) {
        System.out.println("Falha registrada, "+descricao);
    }

    @Override
    public void diagnosticar() {
        System.out.println("Diagnóstico realizado.");
    }

    @Override
    public String produzir() {
        return "Robo produzindo.";
    }

    @Override
    public String status() {
        return "Robo funcionando.";
    }

    @Override
    public void carregarPrograma(String nomePrograma) {
        System.out.println("Programa " + nomePrograma + " carregado no robô.");
    }
}
