package Atividade4_Interfaces.Entities;

public abstract class DispositivoIoT extends Equipamento {
    public DispositivoIoT() {
        super();
    }

    public DispositivoIoT(String codigo, String nome) {
        super(codigo, nome);
    }

    public abstract String coletarDado();
}
