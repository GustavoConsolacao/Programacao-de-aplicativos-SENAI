package Atividade4_Interfaces.Entities.Interfaces;

public interface Manutenivel {
    void agendarManutencao();
    void registrarFalha(String descricao);
    void diagnosticar();
}
