package Atividade4_Interfaces.Entities.Interfaces;

public interface ConectavelIoT {
    void enviarDadosNuvem();
    void receberComando(String comando);
}
