package Atividade4_Interfaces.Entities.Interfaces;

public interface Programavel {
    void carregarPrograma(String nomePrograma);
}
