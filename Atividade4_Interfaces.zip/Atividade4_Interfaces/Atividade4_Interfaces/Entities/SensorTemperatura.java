package Atividade4_Interfaces.Entities;

import Atividade4_Interfaces.Entities.Interfaces.ConectavelIoT;

public class SensorTemperatura  extends DispositivoIoT implements ConectavelIoT {
    public SensorTemperatura() {
        super();
    }
    public SensorTemperatura(String codigo, String nome) {
        super(codigo, nome);
    }
    @Override
    public String status() {
        return "Sensor de temperatura funcionando.";
    }

    @Override
    public String coletarDado() {
        return "Temperatura coletada.";
    }

    @Override
    public void enviarDadosNuvem() {
        System.out.println("Dados do sensor enviados para a nuvem.");
    }
    @Override
    public void receberComando(String comando) {
        System.out.println("Comando recebido: " + comando);
    }
}

