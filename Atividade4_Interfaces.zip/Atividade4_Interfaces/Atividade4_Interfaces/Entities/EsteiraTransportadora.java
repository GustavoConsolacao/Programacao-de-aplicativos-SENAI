package Atividade4_Interfaces.Entities;

import Atividade4_Interfaces.Entities.Interfaces.Manutenivel;

public class EsteiraTransportadora  extends MaquinaProducao implements Manutenivel {
    public EsteiraTransportadora() {
        super();
    }
    public EsteiraTransportadora(String codigo, String nome) {
        super(codigo, nome);
    }
    @Override
    public String status() {
        return "Esteira funcionando.";
    }
    @Override
    public String produzir() {
        return "Esteira transportando produtos.";
    }
    @Override
    public void agendarManutencao() {
        System.out.println("Manutenção da esteira agendada.");
    }
    @Override
    public void registrarFalha(String descricao) {
        System.out.println("Falha registrada: " + descricao);
    }
    @Override
    public void diagnosticar() {
        System.out.println("Diagnóstico realizado.");
    }

}

