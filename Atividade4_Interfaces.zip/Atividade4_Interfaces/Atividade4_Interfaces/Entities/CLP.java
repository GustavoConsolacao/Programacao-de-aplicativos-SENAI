package Atividade4_Interfaces.Entities;

import Atividade4_Interfaces.Entities.Interfaces.ConectavelIoT;
import Atividade4_Interfaces.Entities.Interfaces.Manutenivel;
import Atividade4_Interfaces.Entities.Interfaces.Programavel;

public class CLP extends DispositivoIoT implements Manutenivel, ConectavelIoT, Programavel {
    public CLP() {
        super();
    }
    public CLP(String codigo, String nome) {
        super(codigo, nome);
    }
    @Override
    public String status() {
        return "CLP funcionando.";
    }
    @Override
    public String coletarDado() {
        return "Dados coletados pelo CLP.";
    }
    @Override
    public void agendarManutencao() {
        System.out.println("Manutenção do CLP agendada.");
    }
    @Override
    public void registrarFalha(String descricao) {
        System.out.println("Falha registrada: " + descricao);
    }
    @Override
    public void diagnosticar() {
        System.out.println("Diagnóstico realizado.");
    }
    @Override
    public void enviarDadosNuvem() {
        System.out.println("Dados do clp enviados para a nuvem.");
    }
    @Override
    public void receberComando(String comando) {
        System.out.println("Comando recebido: " + comando);
    }

    @Override
    public void carregarPrograma(String nomePrograma) {
        System.out.println("Programa " + nomePrograma + " carregado no clp.");
    }
}
