package Atividade4_Interfaces.Entities;

public abstract class Equipamento {
    private String codigo;
    private String nome;
    public Equipamento(String codigo, String nome) {
        this.codigo = codigo;
        this.nome = nome;
    }
    public Equipamento() {

    }
    public String getNome() {
        return nome;
    }
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public abstract String status();
}


