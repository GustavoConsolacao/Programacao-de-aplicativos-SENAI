package Atividade4_Interfaces.Entities;

public abstract class MaquinaProducao extends Equipamento {
    public MaquinaProducao() {
        super();
    }

    public MaquinaProducao(String codigo, String nome) {
        super(codigo, nome);
    }

    public abstract String produzir();
}

